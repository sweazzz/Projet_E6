// Test du module de scan - simulation Wokwi
// ESP32 DevKit à la place de l'ESP32-CAM, mêmes broches
const int BP_ENTREE = 13;
const int BP_SORTIE = 14;
const int BUZZER    = 12;
const int LED_VERTE = 2;
const int LED_ROUGE = 15;

// Dans Wokwi le buzzer doit recevoir une fréquence (tone).
// Sur le vrai montage (buzzer actif + transistor), un simple
// digitalWrite(BUZZER, HIGH) suffit.
void bip(int nb) {
  for (int i = 0; i < nb; i++) {
    tone(BUZZER, 2000);
    delay(120);
    noTone(BUZZER);
    delay(120);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(BP_ENTREE, INPUT_PULLUP);   // appui = LOW
  pinMode(BP_SORTIE, INPUT_PULLUP);
  pinMode(LED_VERTE, OUTPUT);
  pinMode(LED_ROUGE, OUTPUT);
  Serial.println("Module de scan pret");
}

void loop() {
  if (digitalRead(BP_ENTREE) == LOW) {
    Serial.println("ENTREE");
    digitalWrite(LED_VERTE, HIGH);
    bip(1);
    delay(500);
    digitalWrite(LED_VERTE, LOW);
  }
  if (digitalRead(BP_SORTIE) == LOW) {
    Serial.println("SORTIE");
    digitalWrite(LED_ROUGE, HIGH);
    bip(2);
    delay(500);
    digitalWrite(LED_ROUGE, LOW);
  }
}